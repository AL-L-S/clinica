<div class="content">

</div>

<link rel="stylesheet" href="<?= base_url() ?>css/jquery-ui-1.8.5.custom.css">
<script type="text/javascript" src="<?= base_url() ?>js/jquery-1.9.1.js" ></script>
<script type="text/javascript" src="<?= base_url() ?>js/jquery-ui-1.10.4.js" ></script>

<script type="text/javascript">

//
//    $.ajax({
//        type: "POST",
//        data: {teste: 'teste'},
//        //url: "http://192.168.25.47:8099/webService/telaAtendimento/cancelar/495",
//        url: "http://192.168.25.47:8099/webService/telaAtendimento/proximo/30/Guichê 1/true/false/12",
//        success: function (data) {
//            console.log(data);
//        },
//        error: function(data){
//            console.log(data);
//            alert('DEU MERDA');
//        }
//    });

</script>